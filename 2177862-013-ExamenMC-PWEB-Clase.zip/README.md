# IMPORTANTE

Mi entrega tiene la API-KEY ni mi matricula por motivos de facilidad de revisión, para poder probarla con otras claves y matriculas es necesario ingresarlas en los campos dentro de [script.js](/scripts/script.js).

Gracias por la extension!!